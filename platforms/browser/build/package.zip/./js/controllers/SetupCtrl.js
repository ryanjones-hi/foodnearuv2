﻿app.controller('SetupCtrl', function($scope, $stateParams) {
    /* ionic.material.motion.pushDown({
        selector: '.push-down'
    });
    */
});